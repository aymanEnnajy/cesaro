-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Jeu 13 Juin 2024 à 18:15
-- Version du serveur: 5.0.45
-- Version de PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de données: `projet_finetude`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `admine`
-- 

CREATE TABLE `admine` (
  `id_admin` int(100) NOT NULL auto_increment,
  `email_admin` varchar(100) NOT NULL,
  `password_admin` varchar(100) NOT NULL,
  `confirm_admin` varchar(100) NOT NULL,
  PRIMARY KEY  (`id_admin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

-- 
-- Contenu de la table `admine`
-- 

INSERT INTO `admine` (`id_admin`, `email_admin`, `password_admin`, `confirm_admin`) VALUES 
(4, 'ayman93011@gmail.com', '2500', '2500'),
(6, 'hassan@gmail.com', 'admin2024', 'admin2024'),
(14, 'zakaria@gmail.com', 'zak', 'zak');

-- --------------------------------------------------------

-- 
-- Structure de la table `avis`
-- 

CREATE TABLE `avis` (
  `ID_AVIS` int(11) NOT NULL auto_increment,
  `ID_UTIL` int(11) NOT NULL,
  `NOM_AVIS` char(100) default NULL,
  `COMMANTAIRE` char(200) default NULL,
  PRIMARY KEY  (`ID_AVIS`),
  KEY `FK_DONNER` (`ID_UTIL`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Contenu de la table `avis`
-- 

INSERT INTO `avis` (`ID_AVIS`, `ID_UTIL`, `NOM_AVIS`, `COMMANTAIRE`) VALUES 
(1, 13, 'hamid', 'trÃ©s bon produit'),
(2, 12, 'ait aali', 'bien'),
(3, 1, 'ennajy', 'good product'),
(4, 3, 'fahd', 'PRODUIT BIEN'),
(5, 3, 'fahd', 'PRODUIT BIEN'),
(6, 3, 'fahd', 'PRODUIT BIEN');

-- --------------------------------------------------------

-- 
-- Structure de la table `categorie`
-- 

CREATE TABLE `categorie` (
  `ID_CATE` int(11) NOT NULL auto_increment,
  `NOM_CATE` varchar(254) NOT NULL,
  PRIMARY KEY  (`ID_CATE`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Contenu de la table `categorie`
-- 

INSERT INTO `categorie` (`ID_CATE`, `NOM_CATE`) VALUES 
(1, 'Robinetterie'),
(2, 'Carrelage');

-- --------------------------------------------------------

-- 
-- Structure de la table `command`
-- 

CREATE TABLE `command` (
  `ID_cmd` int(11) NOT NULL auto_increment,
  `ID_UTIL` int(11) NOT NULL,
  `nomdestin_cmd` varchar(100) NOT NULL,
  `STATUT_cmd` varchar(100) default NULL,
  `DATE_cmd` date NOT NULL,
  `MONTANT_CMD` int(11) NOT NULL,
  `adresseLivr_Cmd` varchar(255) NOT NULL,
  `tel_cmd` varchar(13) NOT NULL,
  `codepostal_cmd` varchar(100) NOT NULL,
  `nom_pdts` varchar(255) NOT NULL,
  PRIMARY KEY  (`ID_cmd`),
  KEY `ID_UTIL` (`ID_UTIL`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- 
-- Contenu de la table `command`
-- 

INSERT INTO `command` (`ID_cmd`, `ID_UTIL`, `nomdestin_cmd`, `STATUT_cmd`, `DATE_cmd`, `MONTANT_CMD`, `adresseLivr_Cmd`, `tel_cmd`, `codepostal_cmd`, `nom_pdts`) VALUES 
(1, 13, 'HAMID DODI', 'paiement a la livraison', '2024-06-10', 1720, 'martil ', '06758980421', '2504', '+Lavabo monotrou +Inverseur Ã  encastrer +Mitigeur lavabo vidage auto cold start'),
(2, 12, 'ait aali halid	', 'paiement a la livraison', '2024-06-11', 13640, 'martil ', '06000551', '49140', '+MIRAGE Glocal â€“ Chamois GC 08 +Mitigeur lavabo vidage auto cold start'),
(3, 1, 'mohamed ayman ennajy', 'paiement a la livraison', '2024-06-12', 1800, 'MASSIRA3 OPP IBN KHALDOUNE 1 B 7 Marrakech', '0676170551', '40140', '+EUROCERAMICA 4152 AQUA MARRON'),
(4, 1, 'mohamed ayman ennajy', 'paiement a la livraison', '2024-06-12', 1800, 'MASSIRA3 OPP IBN KHALDOUNE 1 B 7 Marrakech', '0676170551', '40140', '+EUROCERAMICA 4152 AQUA MARRON'),
(7, 3, 'AMIN AMANI', 'paiement a la livraison', '2024-06-12', 15750, 'OPERATION FIRDAWS AUN CHOCK CASABLANCA', '06480001', '4528', '+MIRAGE Glocal Sugar GC'),
(8, 3, 'mohamed ayman ennajy', 'paiement a la livraison', '2024-06-12', 3600, 'MASSIRA3 OPP IBN KHALDOUNE 1 B 7 Marrakech', '0676170551', '40140', '+EUROCERAMICA 4152 AQUA MARRON'),
(9, 15, 'mohamed ayman ennajy', 'paiement a la livraison', '2024-06-13', 700, 'MASSIRA3 OPP IBN KHALDOUNE 1 B 7 Marrakech', '0676170551', '40140', '+colorado mitigeur');

-- --------------------------------------------------------

-- 
-- Structure de la table `contact`
-- 

CREATE TABLE `contact` (
  `id_contc` int(11) NOT NULL auto_increment,
  `nomComp_contc` varchar(50) NOT NULL,
  `email_contc` varchar(70) NOT NULL,
  `tele_contc` varchar(12) NOT NULL,
  `message_contc` varchar(255) NOT NULL,
  PRIMARY KEY  (`id_contc`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

-- 
-- Contenu de la table `contact`
-- 

INSERT INTO `contact` (`id_contc`, `nomComp_contc`, `email_contc`, `tele_contc`, `message_contc`) VALUES 
(1, 'mohamed ayman ennajy', 'ayman93011@gmail.com', '0676170551', 'hello, please can you tell if possible to buy a set of taps and sanitary ware with beige color and you give me a tile almost similar to this material'),
(2, 'rachid aalami', 'ggg@gmail.com', '633550', 'j''ai un problem que ma commande il est en retard'),
(9, 'mohamed ayman ennajy', 'ayman93011@gmail.com', '0676170551', 'good'),
(10, 'samira', 'SAMIRA.587@GMAIL.COM', '0658888', 'bonjour j''ai un probleme que le produit est cassÃ©');

-- --------------------------------------------------------

-- 
-- Structure de la table `facture`
-- 

CREATE TABLE `facture` (
  `ID_UTIL` int(11) NOT NULL,
  `ID_FACT` int(11) default NULL,
  KEY `FK_PAIER` (`ID_UTIL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `facture`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `fournir`
-- 

CREATE TABLE `fournir` (
  `ID_PDT` int(11) NOT NULL,
  `ID_FOUR` int(11) NOT NULL,
  PRIMARY KEY  (`ID_PDT`,`ID_FOUR`),
  KEY `FK_FOURNIR` (`ID_FOUR`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `fournir`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `fournisseur`
-- 

CREATE TABLE `fournisseur` (
  `ID_FOUR` int(11) NOT NULL auto_increment,
  `NOM_FOUR` char(250) default NULL,
  `PRENOM_FOUR` char(250) default NULL,
  `ADRESSE_FOUR` longtext,
  `TEL_FOUR` char(250) default NULL,
  `MAIL_FOUR` text,
  PRIMARY KEY  (`ID_FOUR`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `fournisseur`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `panier`
-- 

CREATE TABLE `panier` (
  `id_adcart` int(11) NOT NULL auto_increment,
  `ID_UTIL` int(11) NOT NULL,
  `pdtNam_adcart` varchar(255) NOT NULL,
  `pdtPrice_adcart` decimal(10,0) NOT NULL,
  `pdtmontantTotal_adcart` decimal(10,0) NOT NULL,
  `order_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `quanti_addcart` int(11) NOT NULL,
  PRIMARY KEY  (`id_adcart`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- 
-- Contenu de la table `panier`
-- 

INSERT INTO `panier` (`id_adcart`, `ID_UTIL`, `pdtNam_adcart`, `pdtPrice_adcart`, `pdtmontantTotal_adcart`, `order_date`, `quanti_addcart`) VALUES 
(5, 3, 'Mitigeur lavabo vidage auto cold start', '520', '520', '2024-06-12 23:05:43', 1),
(6, 3, 'Mitigeur lavabo', '120', '120', '2024-06-12 23:06:02', 1);

-- --------------------------------------------------------

-- 
-- Structure de la table `produit`
-- 

CREATE TABLE `produit` (
  `ID_PDT` int(11) NOT NULL auto_increment,
  `categorie_prod` varchar(100) NOT NULL,
  `NOM_PDT` char(250) default NULL,
  `DESCR_PDT` char(250) default NULL,
  `PRIX_PDT` int(11) default NULL,
  `image_pdt` varchar(255) NOT NULL,
  PRIMARY KEY  (`ID_PDT`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

-- 
-- Contenu de la table `produit`
-- 

INSERT INTO `produit` (`ID_PDT`, `categorie_prod`, `NOM_PDT`, `DESCR_PDT`, `PRIX_PDT`, `image_pdt`) VALUES 
(1, '1', 'colorado mitigeur', 'Robinetterie de cuisine avec bec pivotant Ã  360Â°. Son design industriel et ses diffÃ©rentes dÃ©clinaisons de couleurs sauront s''adapter Ã  tous les styles de cuisines.   Grande praticitÃ© grÃ¢ce au bec haut et pivotant du mitigeur : bel espace de t', 700, 'images/pdt1-1.jpg'),
(2, '1', 'Mitigeur lavabo vidage auto cold start', 'Economie d''eau et d''Ã©nergie  Finition: ChromÃ©  Flexible d''alimentation: 3/8"  Flexible d''alimentation inclus  Lieux d''installation: Lavabo  Ouverture centrale sur l''eau froide  Type d''installation: Sur plan  Type de robinetterie: Mitigeur  Type de', 520, 'images/pdt1-2.jpg'),
(3, '1', 'Lavabo monotrou', 'Lavabo monotrou, corps lisse avec vidage clic-clac, Cold Start', 850, 'images/pdt1-4.jpg'),
(4, '2', 'CERACASA Absolute vision', 'Carrelage  PÃ¢te blanche Brillant Facile Ã  lâ€™entretien RÃ©sistance Ã  lâ€™humiditÃ©', 120, 'images/pdt1.jpg'),
(5, '2', 'MIRAGE Glocal â€“ Chamois GC 08', 'Carrelage PÃ¢te blanche Brillant Facile Ã  lâ€™entretien RÃ©sistance Ã  lâ€™humiditÃ©', 140, 'images/pdt4.png'),
(6, '1', 'Mitigeur lavabo', 'Mitigeur lavabo avec vidage clic-clac. Bec fixe  Click-clack waste  Finition: ChromÃ©  Flexible d''alimentation: 3/8"  Flexible d''alimentation inclus  Lieux d''installation: Lavabo  Position du bec: Central  Type d''installation: Sur plan', 120, 'images/produit6.jpeg'),
(7, '2', 'EUROCERAMICA 4152 AQUA MARRON', 'Imitation de marbre Une combinaison de marbre et de bois . Surface brillante PremiÃ¨re qualitÃ© Fabricant Espagne', 100, 'images/pdt6.png'),
(8, '2', 'MIRAGE Glocal Sugar GC', 'Surface brillante PremiÃ¨re qualitÃ© Fabricant Espagne. Imitation de marbre Une combinaison de marbre et de bois', 250, 'images/pdt7.png'),
(9, '2', 'Lavicas gris', 'Surface brillante PremiÃ¨re qualitÃ© Fabricant Espagne. Imitation de marbre Une combinaison de marbre et de bois', 180, 'images/property-04.jpg'),
(10, '2', 'Crash beige', 'Surface brillante PremiÃ¨re qualitÃ© Fabricant Espagne. Imitation de marbre Une combinaison de marbre et de bois', 185, 'images/pdt2.jpg'),
(11, '2', 'Dana gold', 'Surface brillante PremiÃ¨re qualitÃ© Fabricant Espagne. Imitation de marbre Une combinaison de marbre et de bois', 145, 'images/pdt3.png'),
(12, '1', 'Mitigeur Pour Bidet Monotrou', 'Mitigeur pour bidet monotrou Ã  jet mobile, livrÃ© avec vidage automatique et flexibles dâ€™alimentation. Ouverture sur l''eau froide.', 650, 'images/robini2.jpg'),
(13, '1', 'LUNDA Mitigeur', 'Robinet haut Ã  douchette montÃ©e sur flexible, maintenu en position par un bras pivotant Ã  360Â°. Deux jets au choix pour deux fois plus d''efficacitÃ©. Le changement de jet s''opÃ¨re via le bouton poussoir sur la douchette. \r\n', 1000, 'images/produit5.jpg'),
(14, '1', 'BASIC - - Robinet de chasse 3/4" pour WC', 'BASIC - - Robinet de chasse 3/4" pour WC. Finition: ChromÃ©  Flexible d''alimentation: 3/4"  Lieux d''installation: WC  Tube d''Ã©vacuation: IncurvÃ©  Type d''installation: Mural  Type de poignÃ©e: T-Handle  Type de robinetterie: Technologie temporisÃ©e', 1050, 'images/robini3.jpg'),
(15, '1', 'Inverseur Ã  encastrer', 'Inverseur Ã  encastrer (2 voies) pour bain ou douche. Finition: ChromÃ©\r\n\r\nFlexible d''alimentation: 1/2"\r\n\r\nLieux d''installation: Baignoire, Douche\r\n\r\nNombre de voies: 2\r\n\r\nType d''installation: EncastrÃ©', 350, 'images/robini1.jpg'),
(16, '1', 'MÃ©langeur lavabo', 'MÃ©langeur lavabo bec haut avec vidage clic-clac.\r\nLieux d''installation: Lavabo\r\n\r\nType d''installation: Sur plan\r\n\r\nType de robinetterie: MÃ©langeur', 1800, 'images/robini4.jpg'),
(17, '2', 'ECOCERAMIC Essential Gold', 'Surface brillante\r\nPremiÃ¨re qualitÃ©\r\nFabricant Espagne. Imitation de marbre\r\nUne combinaison de marbre et de bois', 205, 'images/carr2.jpg'),
(18, '1', 'Mitigeur thermostatique encastrÃ© pour douche', 'Mitigeur thermostatique encastrÃ© pour douche. Lieux d''installation: DoucheSÃ©lection de la tempÃ©ratureType d''installation: EncastrÃ©Type de cartouche: Thermostatique', 1200, 'images/rob3.png'),
(19, '1', 'Mitigeur thermostatique encastrÃ©', 'Mitigeur thermostatique encastrÃ© pour douche Lieux d''installation: Douche\r\n\r\nSÃ©lection de la tempÃ©rature\r\n\r\nType d''installation: EncastrÃ©\r\n\r\nType de cartouche: Thermostatique\r\n\r\nType de robinetterie: Thermostatique', 1250, 'images/robini5.jpg'),
(20, '1', 'Lavabo monotrou Ã  bec tube mobile', 'Lavabo monotrou Ã  bec tube mobile haut livrÃ© avec vidage automatique en laiton et flexibles d''alimentation\r\nFinition: ChromÃ©\r\n\r\nFlexible d''alimentation inclus\r\n\r\nLieux d''installation: Lavabo\r\n\r\nMÃ©langeur: 1/2 tour\r\n\r\nType d''aÃ©rateur: IntÃ©grÃ©\r\n', 650, 'images/robini6.jpg'),
(21, '2', 'Sahara Noir', 'Imitation de marbre Une combinaison de marbre et de bois . Surface brillante PremiÃ¨re qualitÃ© Fabricant Espagne	', 145, 'images/casablanca.jpg'),
(22, '2', 'Balbi Indian rect gres ceram', 'Surface brillante PremiÃ¨re qualitÃ© Fabricant Espagne. Imitation de marbre Une combinaison de marbre et de bois	', 350, 'images/carr3.jpg'),
(23, '2', 'Magnes Beige Recer', 'Surface brillante PremiÃ¨re qualitÃ© Fabricant Espagne. Imitation de marbre Une combinaison de marbre et de bois	', 360, 'images/carre2.jpg'),
(24, '2', 'Serastone Serie', 'Offrant un concept extraordinaire avec sa conception vibrante et colorÃ©e, Serastone Ã©voque une texture diffÃ©rente avec chaque cadre. Les produits, qui Ã©voquent un effet saisissant avec leurs lignes minimalistes et leurs transitions de couleurs\r\n', 350, 'images/carr5.jpg');

-- --------------------------------------------------------

-- 
-- Structure de la table `util`
-- 

CREATE TABLE `util` (
  `ID_UTIL` int(255) NOT NULL auto_increment,
  `NOM_UTLI` char(250) default NULL,
  `PRENOM_UTLI` char(250) default NULL,
  `ADRESSE__UTLI` char(250) default NULL,
  `email_util` char(250) default NULL,
  `TEL_UTLI` char(250) default NULL,
  `CODE_POSTAL` char(250) default NULL,
  `VILLE_UTIL` char(250) default NULL,
  `GENRE_UTIL` char(250) default NULL,
  `Password_uti` varchar(100) NOT NULL,
  `confirm_password` varchar(100) NOT NULL,
  PRIMARY KEY  (`ID_UTIL`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- 
-- Contenu de la table `util`
-- 

INSERT INTO `util` (`ID_UTIL`, `NOM_UTLI`, `PRENOM_UTLI`, `ADRESSE__UTLI`, `email_util`, `TEL_UTLI`, `CODE_POSTAL`, `VILLE_UTIL`, `GENRE_UTIL`, `Password_uti`, `confirm_password`) VALUES 
(1, 'ennajy', 'mohamed ayman', 'MASSIRA3', 'ayman93011@gmail.com', '0676170551', '40140', 'marrakech', 'Homme', 'aa', 'aa'),
(2, 'hasaan', 'mousaab', 'ain diyab', 'malla@gmail.com', '060000', '35444', 'casablnca', 'Homme', '150', '150'),
(3, 'fahd', 'mousa', 'saht lhdim', 'alla@gmail.com', '060000', '35444', 'Rabat', 'Homme', '150', '150'),
(4, 'amin', 'aali', 'casabarata', 'nala@gmail.com', '060000', '35444', 'tanger', 'Homme', '150', '150'),
(5, 'salma', 'fadi', 'ain diyab', 'salla@gmail.com', '060000', '35444', 'casablnca', 'Femme', '500', '500'),
(6, 'ali', 'fadi', 'rabat agdal', 'ar00@gmail.com', '0698751', '4587', 'rabat', 'Homme', '0000', '0000'),
(7, 'test', 'test', 'doha 44 marrakech', 'test@gmail.com', '05888', '1936', 'marrakech', 'Homme', 'aaaa', 'aaaa'),
(12, 'ait aali', 'mohamed', 'Agadir hay salam', 'an93011@gmail.com', '0676170551', '40', 'Agadir', 'Homme', 'aaa', 'ddd'),
(13, 'hamid', 'dodi', 'martil ffff', 'hamid.mm@gmail.com', '048208', '7581', 'martil', 'Homme', '450', '450'),
(14, 'ennajy', 'mohamed ayman', 'MASSIRA3 OPP IBN KHALDOUNE 1 B 7 Marrakech', 'aaad@gmail.com', '0676170551', '40140', 'marrakech', 'Homme', 'as', 'as'),
(15, 'SAMIRA', 'AMIRA', 'ouazzan hay adarisa', 'SAMIRA.587@GMAIL.COM', '0652884147', '1450', 'ouazzan', 'Femme', 'kl', 'kl');

-- 
-- Contraintes pour les tables exportées
-- 

-- 
-- Contraintes pour la table `avis`
-- 
ALTER TABLE `avis`
  ADD CONSTRAINT `FK_DONNER` FOREIGN KEY (`ID_UTIL`) REFERENCES `util` (`ID_UTIL`);

-- 
-- Contraintes pour la table `command`
-- 
ALTER TABLE `command`
  ADD CONSTRAINT `command_ibfk_1` FOREIGN KEY (`ID_UTIL`) REFERENCES `util` (`ID_UTIL`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Contraintes pour la table `facture`
-- 
ALTER TABLE `facture`
  ADD CONSTRAINT `FK_PAIER` FOREIGN KEY (`ID_UTIL`) REFERENCES `util` (`ID_UTIL`);

-- 
-- Contraintes pour la table `fournir`
-- 
ALTER TABLE `fournir`
  ADD CONSTRAINT `FK_FOURNIR` FOREIGN KEY (`ID_FOUR`) REFERENCES `fournisseur` (`ID_FOUR`),
  ADD CONSTRAINT `FK_FOURNIR2` FOREIGN KEY (`ID_PDT`) REFERENCES `produit` (`ID_PDT`);
